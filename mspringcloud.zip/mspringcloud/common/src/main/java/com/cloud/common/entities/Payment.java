package com.cloud.common.entities;

import lombok.Data;

@Data
public class Payment {
    private long id;
    private String mSerial;
}
